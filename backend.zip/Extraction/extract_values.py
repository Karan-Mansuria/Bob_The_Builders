import os
import json
from pathlib import Path
from typing import Dict, Optional
import re

from transformers import pipeline

# ---------------- Model Loader ----------------
_nlp: Optional[object] = None


def load_model() -> object:
    """
    Load a lightweight, instruction-tuned model.
    (Uses MBZUAI/LaMini-Flan-T5-783M — optimized for question-answering & text extraction)
    """
    global _nlp
    if _nlp is not None:
        return _nlp
    offload_dir = Path("test") / "model_offload"
    offload_dir.mkdir(parents=True, exist_ok=True)

    candidates = [
        ("MBZUAI/LaMini-Flan-T5-783M", "LaMini-Flan-783M"),
        ("google/flan-t5-base", "FLAN-T5-base"),
        ("google/flan-t5-small", "FLAN-T5-small"),
    ]

    last_err = None
    for model_id, label in candidates:
        try:
            print(f"[info] Loading model: {label} ({model_id})...")
            _nlp = pipeline(
                task="text2text-generation",
                model=model_id,
                device_map="auto",
                model_kwargs={
                    "low_cpu_mem_usage": True,
                    "offload_folder": str(offload_dir),
                },
            )
            print("[info] Model loaded successfully.")
            return _nlp
        except Exception as e:
            last_err = e
            print(f"[warn] Failed to load {model_id}: {e}")

    # If all candidates failed, raise the last error
    raise RuntimeError(f"Could not load any model. Last error: {last_err}")


# ---------------- Core Extraction ----------------
_RE_RUPEE = re.compile(
    r"(?:₹|rs\.?|inr)\s*[:=~\-]?\s*[0-9][0-9, ]*(?:\.[0-9]{1,2})?(?:\s*(?:lakh|lakhs|crore|crores|million|bn|billion))?",
    re.IGNORECASE,
)
_RE_NUM = re.compile(r"\b[0-9][0-9, ]*(?:\.[0-9]{1,2})?\b")


def _normalize_commas(val: str) -> str:
    # Fix spaces after commas like "37, 50,000" -> "37,50,000"
    return re.sub(r",\s+", ",", val)


def _extract_numeric_or_rupee(text: str) -> str:
    if not text:
        return ""
    m = _RE_RUPEE.search(text)
    if m:
        return _normalize_commas(m.group(0).strip())
    m2 = _RE_NUM.search(text)
    if m2:
        return _normalize_commas(m2.group(0).strip())
    return ""


def _score_candidate(val: str) -> tuple[int, int, int]:
    """
    Score: higher is better.
    - has currency keyword (₹/Rs/INR) -> 2
    - has unit (lakh/crore/million/bn/billion) -> 1
    - numeric magnitude (length of digits) -> tie-breaker
    """
    vlow = val.lower()
    has_curr = 2 if ("₹" in val or vlow.startswith("rs") or vlow.startswith("inr")) else 0
    has_unit = 1 if any(u in vlow for u in ["lakh", "lakhs", "crore", "crores", "million", "bn", "billion"]) else 0
    digits = re.sub(r"\D", "", val)
    return (has_curr, has_unit, len(digits))


def _select_best_candidate(cands: list[str]) -> str:
    if not cands:
        return ""
    # Normalize and deduplicate while preserving order
    normed: list[str] = []
    seen = set()
    for c in cands:
        n = _normalize_commas(c.strip())
        if n and n not in seen:
            seen.add(n)
            normed.append(n)
    if not normed:
        return ""
    normed.sort(key=_score_candidate, reverse=True)
    return normed[0]
def _build_prompt(param_name: str, text_block: str) -> str:
    """
    Build a short and specific prompt for value extraction.
    """
    instruction = (
        f"Extract only the rupee or numeric value corresponding to '{param_name}' "
        "from the text below. Return only the value, no words, no explanation.\n\n"
        "Text:\n"
    )
    snippet = text_block.strip()
    if len(snippet) > 2500:
        snippet = snippet[:2500]
    return instruction + snippet


def extract_value(param_name: str, text_block: str) -> str:
    """
    Use the model alone (no regex) to extract numeric or rupee values.
    """
    try:
        nlp = load_model()
        prompt = _build_prompt(param_name, text_block)
        result = nlp(prompt, max_new_tokens=32)
        value = result[0].get("generated_text", "").strip()
        # Clean basic noise like punctuation or phrases
        if ":" in value:
            value = value.split(":")[-1].strip()
        # Normalize casing and common prefixes
        low = value.lower()
        if low.startswith("rs ") and not value.startswith("Rs. "):
            value = "Rs. " + value[3:].strip()
        if low.startswith("inr ") and not value.upper().startswith("INR "):
            value = "INR " + value[4:].strip()
        # Post-filter to keep only a currency/number looking substring
        filtered = _extract_numeric_or_rupee(value)
        if filtered:
            return filtered
        # Normalize 'none'/'null' outputs to blank
        if low in {"none", "null", "n/a", "na", "not provided", "not available"}:
            return ""
        return value or ""
    except Exception as e:
        print(f"[error] Extraction failed for '{param_name}': {e}")
        return ""


# ---------------- Section Processing ----------------
def _parse_sections(text: str) -> Dict[str, str]:
    """
    Parse sections in the format:
    -- param_name --
    [text...]
    """
    sections: Dict[str, str] = {}
    current = None
    buf = []

    for line in text.splitlines():
        line = line.strip()
        if line.startswith("--") and line.endswith("--"):
            if current and buf:
                sections[current] = "\n".join(buf).strip()
                buf = []
            current = line.strip("- ").replace(" ", "_").lower()
        elif current:
            buf.append(line)

    if current and buf:
        sections[current] = "\n".join(buf).strip()

    return sections


def process_extracted_blocks(folder: str = "test/extracted_pages_new") -> Dict[str, str]:
    """
    Prefer processing per-parameter snippet files to avoid token limits.
    If not present, fallback to monolithic tender_context.txt sections.
    """
    folder_path = Path(folder)
    ctx_dir = folder_path / "param_contexts"

    if ctx_dir.exists() and ctx_dir.is_dir():
        print(f"[info] Using per-parameter snippets from: {ctx_dir}")
        # Gather files grouped by param prefix
        grouped: Dict[str, list[Path]] = {}
        for p in sorted(ctx_dir.glob("*.txt")):
            name = p.stem  # e.g., estimated_cost_001
            if name == "INDEX":
                continue
            if "_" in name:
                key = name.rsplit("_", 1)[0]
            else:
                key = name
            grouped.setdefault(key, []).append(p)

        results: Dict[str, str] = {}
        for key, files in grouped.items():
            print(f"[info] Extracting value for: {key} ({len(files)} snippets)")
            candidates: list[str] = []
            for fp in files:
                block = fp.read_text(encoding="utf-8", errors="ignore")
                # strip optional header lines we added
                block_lines = [ln for ln in block.splitlines() if not ln.startswith("# ")]
                # Keep only lines likely to contain numbers to reduce prompt size
                focus_lines = [ln for ln in block_lines if any(ch.isdigit() for ch in ln)] or block_lines
                cleaned_block = "\n".join(focus_lines).strip()
                cand = extract_value(key, cleaned_block)
                cand = _extract_numeric_or_rupee(cand) or cand
                if not cand:
                    # Try fallback regex from the snippet itself
                    cand = _extract_numeric_or_rupee(cleaned_block) or ""
                if cand:
                    candidates.append(cand)
            best = _select_best_candidate(candidates)
            results[key] = best
            print(f"  -> {key}: {best}")

        out_path = folder_path / "tender_values.json"
        out_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"[info] Saved results to: {out_path}")
        return results

    # Fallback to monolithic context file
    ctx_path = folder_path / "tender_context.txt"
    if not ctx_path.exists():
        print(f"[error] No context sources found. Missing: {ctx_dir} and {ctx_path}")
        return {}

    print(f"[info] Reading context file: {ctx_path}")
    text = ctx_path.read_text(encoding="utf-8", errors="ignore")
    sections = _parse_sections(text)
    if not sections:
        print("[warn] No sections detected with -- parameter -- markers.")

    results: Dict[str, str] = {}
    for key, block in sections.items():
        print(f"[info] Extracting value for: {key}")
        value = extract_value(key, block)
        results[key] = value
        print(f"  -> {key}: {value}")

    out_path = folder_path / "tender_values.json"
    out_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[info] Saved results to: {out_path}")
    return results


# ---------------- Main ----------------
if __name__ == "__main__":
    process_extracted_blocks()
